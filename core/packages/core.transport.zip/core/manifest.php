<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ae4bd0a26035add9decfc9bdeaa41d3f',
      'native_key' => 'core',
      'filename' => 'modNamespace/0aa3ff9eaf26c7836d68dc355868a250.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '556946b52e3ef55788913ba0e8c1a2e4',
      'native_key' => 1,
      'filename' => 'modWorkspace/115bcd798460c11057d5fbbce46bc88e.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '41e5a98838a3fbb8ad163762c0e597c9',
      'native_key' => 1,
      'filename' => 'modTransportProvider/d1ac7332dd722f0cfd39399fa41b710c.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fbeb1e10e13165333cbdb6ce2d585c12',
      'native_key' => 'topnav',
      'filename' => 'modMenu/e801543cdaba17e743fcfa64e4ff98fa.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b26a2e4f0f5bf607479da7446123de32',
      'native_key' => 'usernav',
      'filename' => 'modMenu/1deab580b9226806fdb85f72b811300e.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'aa40d63a2c34b07dfb481e251a420bbe',
      'native_key' => 1,
      'filename' => 'modContentType/66dbb2dc76286726988f65de1fe15a07.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '664405c1e77150a5de4fe6caaa54f668',
      'native_key' => 2,
      'filename' => 'modContentType/926de3dcb1547ad13db6ba915910294c.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '61a729e7b42be6fa000a8792fcc6275e',
      'native_key' => 3,
      'filename' => 'modContentType/b6b049e49f8490d42e497ede5412bf2c.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'cc3a21c43db215b0e437d63b8375e3a3',
      'native_key' => 4,
      'filename' => 'modContentType/bd812bbf100a6fd7d896c9b5673fa6c2.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5bf306a12e0f11041666aa54b16fbadc',
      'native_key' => 5,
      'filename' => 'modContentType/7002abb4ab287d6132a27f65705c4a46.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '71937842ac9405d576d9a6ecc937332f',
      'native_key' => 6,
      'filename' => 'modContentType/38a839e0f14fa433f6977418dbc88db3.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '33fc50af22f815eb6b8f725c20ff8f7c',
      'native_key' => 7,
      'filename' => 'modContentType/4e4def364550ff299a968e8f2f9914c7.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'bb539b22904c67a4dc619185470d6236',
      'native_key' => 8,
      'filename' => 'modContentType/7edbc5a716110aa9a1618554ea0020c3.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '407c9d3d19c783641217849703f466c7',
      'native_key' => NULL,
      'filename' => 'modClassMap/ea3edb5e0b3e0fd4ecdeeab31f492f72.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4bb0aecd33102e5960f4898856fd41d8',
      'native_key' => NULL,
      'filename' => 'modClassMap/dd1e5319db7a48024a2beb2c9d7b49ce.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '75397d50c2fdcb304c75509e1a61c5cc',
      'native_key' => NULL,
      'filename' => 'modClassMap/46028705313a27c18c44d9ec564ee859.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '34b14c4809308a73032971fb58a36f2b',
      'native_key' => NULL,
      'filename' => 'modClassMap/d8952e3465ce5d914455abdba736fc17.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b39b4619fee2565039d617e36b541204',
      'native_key' => NULL,
      'filename' => 'modClassMap/a79276efecece9c293d5e1e8b46df506.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7c01207ba867c9bcb8e97840d533d372',
      'native_key' => NULL,
      'filename' => 'modClassMap/6970c8c543546c79f1a5c1d05730aff5.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3b2f6d33221a57edde2e69998c6f092b',
      'native_key' => NULL,
      'filename' => 'modClassMap/3ff0715f39aad0c1a18d37d86d459d3b.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '053a1df354eb2f75716742248d341bcf',
      'native_key' => NULL,
      'filename' => 'modClassMap/25efb881e6c0cecf2ae24aef93a8f166.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '90fb7f46919129475d35fee027575eea',
      'native_key' => NULL,
      'filename' => 'modClassMap/06dfda650dd3958846279d72d16ac87d.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a34c4d3e9aff60e3800782b6364112cf',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/615f4dda85649bbb0ddf8bda10160257.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db570a50f733dafdf88f9f7a6fb1f6e4',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/68387c2b611836aec6d043d887e40d41.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8841c205ab2a9f206b02212a00aa387b',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/734baf8ba3dbf6d1bfcf5886f8bdc668.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c4cacbf22753ff19af77b05c9ee4119',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/043588c1d882471116c121030c1eb0bf.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03f386276e888a311df923d16ba2d8de',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/e4f3cb3d61b53a7f6713d6f4fbde53e5.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c4cca8608a9b71103057d400bb4ec1b',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/702211915975c2d0ad616953ced1140e.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e95e5581faf836de9509a2004cb43ef',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/7ecf05d76f450d1c15dd2b3ecf3e81c6.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '492e535a6de1a88599e7c4adf3ceb1be',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/27e1cd3d4d0f81e98a340f0846edb410.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d00b50918b26b128ed206a28fc5833f',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/ddd6c5dbba036e7a4a718ccdbe6a69bb.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c55ba11a1be1776ff0e050b30bb31800',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/5560e00153b7f3b7fc91149c735c947f.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39ebf73fd8f411ec7586f171dced4bdd',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/86ba3fce46fc7be3cf0224a05f120a5c.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb5e7ed97f48b06fe66bab2e5eabfc6e',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/eec555de3e39ba53789dd0fce92426a9.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86cc1107e27a08280f9f58f0d737ebcd',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/8c6c2a667ec9783f0f021b0b0cee225b.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb8161209dfaac8d6340c29b5386a5d6',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/8cf06b591913725544a9e8899041745a.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83e0c4272db7f00f5780ece90d2bde54',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/1ac8c69ef1aa913af1b67e9bc747ab48.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d71f1c10aaf1b3b21365e71a617de3a',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/97bce15faa2ad77ce87c22e2646082c9.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e4572330b69f1123d0fbbffe1d01209',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/f02de633fa81c9233062e306bb17dbbb.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7c41f93c082ec48da9b5ae810e36f91',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/dbf757dd58d47d5dcb09b97824f558ad.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc26b03941366c37a19dcb5babc075e5',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/64e97d03d96533e6a151947d2608683e.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df4b38b9e17cd3f240d0eeaa1e35392b',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/e98181e9025041769d2cf09d2e13eff1.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6ca3e2ddb8b6762f32b549c388122a9',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/1eb04322446d3ec2bc28ad0ee1eb1871.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e86a94c934e39018880c4677f223950',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/cf4180ea399636ce08d12e62aa7e4e5d.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45c19c9067a7a948711899db52d1cd1a',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/83540246f992aaa11031c3019766fd05.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81e54fe7261c64f19f3283bd26f14ab1',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/605536d31b17b699aa8fb82475517ec6.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8029983a9aef6274b9a9333b2cbed5f',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/e883d877707eb91eb4b00f61c71e387d.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9209090c01d85b7c967ad2f597c8b2c8',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/ed26513c37e625155ad81e1149c28e3a.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd74a9542cd55ae0da23e53fccf67fafc',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/c3fda58fbf4b734d056aed4f5ccb67bd.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fdc750598923f625a96b9786878b16b',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/49469e7ada5b30ee95b915bd80247f80.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3189273dc1239e642a1147e41ab8302c',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/429347805906eb7e04a784e3e4a52bfd.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '625125e4f22e0d04919fe7102e811afb',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/6ea2854518af78011a9f0b42bf3edd5f.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '442b1066b4aa85dcadac35b5539c3a0f',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/71c7993a94cb8a12c1dcf2bfaa86c2d5.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3fe78a989dccbed28f0743bbce4e460',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/ad3b025c1d75ae0ef3814e8bbc1f7acc.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebd8529b38d535fae173009b4036621a',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/4f3cbb452fd250c341159a9c9654d85c.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '831f6763418f52cc0bc65ca1473d167c',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/ae2c415d38781a07864c075bdee7709e.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1771f8844632a6c4a10f2d06babcccf',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/62bb659e218d9ce7f89495dba5e6eaf9.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e0eaa48fd38400a4415ab07af3d15ac',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/06c2bff2a7c0e2672ba50f120a9c75a4.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3707c7f981fb50b389f5aa3e9e2c2eb0',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/910073ebbdc1f2f75c0727f5d3b1e6c1.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ca18f3b7fb1db5581dd683c0f983581',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/aeedccdbc6b5840b94811062e5b7513a.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25d85cc067e29f2c7a20dea2d4f66e40',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/521e7e31b248aac5d49852f507d976eb.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e30d4efa4664cbef17be3f0a263a1c3',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/292648e8ef488b95aa29b6d799b3ad2d.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07259c8b1f9356a8242ce9773ba4e9de',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/65a1f8dcbc1eb1eeadee338d20e5a2bb.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0760f54573ac760311111b2204993440',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/3df8515e95910e88c9eb93235d6e47ba.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94e56e3ec492ddcf310aca9071dba6b0',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/b408a195ff944e519b9446cd6d2808ee.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b27bba922b51013cd179ea53a2f9ec15',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/6229c7e0f0ded9c3947d60d5aae63b96.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47c436ca0b77911f4486259b83e8dd29',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/1e9c69abe206fc486b43e74df65a9bb0.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47e3e70f09406bf9b125264159120735',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/d4282cdcb8ab35b36f6abe8a86366027.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e43c24a06886f3a7a4c869f35fe92ff0',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/5b463d1e2874cf7e86351a30d48dd33e.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5807a66985b7fbe53bb785c096a16428',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/549ff2c4ed15eeea1ae1bd389cf90aa9.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e798d2fe52f3b9b135465406bb79c3ec',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/f65c97f5eba31e7a85213a618afaec82.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '640b253f5033cea8ec8071b4cb6749cd',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/9b3d5342e1b4691da6d10a1dd0826a33.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f8ece503174d8dd2d46aad0352a30b8',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/242b860f53a53f2761eb0b2c1f39159a.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fdf8be226aa64017c8d80c80da7afe8',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/924a18c486a0d51e94419eb8747c5754.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb69841ba2c5dc6dc81582911196b0c7',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/5be15acea5b525176fb8deb2e6b05cde.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '341005f63906a02656e410c1ba4d3245',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/8475f032e2b684e1faf7ded081b9229a.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '643ed92b70b9f96e9fccf67dbb6dbba9',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/6cd459c2da02255c393ba3983d52bc7c.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91870bb4b0344cdffab512793da3d8b9',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/c940710eb8eb86d49e5228e04b00776b.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8470b1340f283e864cf384cfc527daa9',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/ed9ca4c7c587fe9ada32f90f21cf0ad0.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a93f1c9dbb6822609549ebe202e17ca3',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/b506b12cbf5bdc7bb78b2878a4588814.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67b997dd2a9f8561c19f246e1d9157da',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/ff8c5a261f1295d29eaccd3ba2c7ba5b.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35f306befb50491320eaaba53211327f',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/79bc4664938229edfebd40562998813a.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b3ddd944f7b2d6f5b7b3a8216321da3',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/a2c77389bdfc3febe086b7a4358306b8.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '659d77c5234f4d4b35a837902facdf39',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/e9e3d41c993a6c3cb9c65c2362456701.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4cc0597834b5008aa78a790ca6d732c',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/be9c4271ad0600af30a648b8994fe45a.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f329cbe436565059a25ad404028dafd',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/3f232e6744bd714c31ebe2394f052613.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eacd629523ab557f0c3dd08f5abf3193',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/566f7f19c3b95da98ee20d39dad5a020.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13104f28dd084fcd0fd0670abed05095',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/62e0c76e6e887c9e74b9e8d2c858437c.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a174223dacaba20c72c2f8fdfcf925bd',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/5f1d01822098f97aeaa2a3523c9d319d.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '140fbd88750906e971a4e91046d70914',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/05d0492186a1bb6ce23081e0ef7df23b.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1ba36dee057f94ac5e025fd9e1e4622',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/792d7844873801a5018cf1abe5d8e7ea.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b18969688585471db39f06ca1e7bb03e',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/61f001db3e1cfa8eef2886ae8a081088.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0e32acb5d8124d84bb295d827dfd4e2',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/52d9f8fd23227dde8cff51b34dac1608.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '212232bbcbe12174cf874093ce6f4c8f',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/029bc231ede9a869592d7989426284d2.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f912e71a6695f53ea30d5569a822ff2',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/2dd1b95ce62edc831fc07342f136d19f.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b992715580232f0437fdf113a0f82e8',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/ad1db033d0eb789ee5e4a92017c64636.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29173fa80c43b6b6c0d6d4e6b7b73131',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/e5616d26fe22a940796d09fb54ea783a.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '703cbbf3699c7f0f0b6a075c755b4cb7',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/8c4ceda76207f037eae0f470ea3067a2.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9584852e862328d0ab1d94d6068ac680',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/08ccdae31b18ef3092eb437a6789bd55.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d8932177d106cf08d6f2f7056ae1f2f',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/db6d947fb8abaef15b4ba1ccab7544f0.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a64bce6a7804a011af48e2a6ca84f35',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/70610f73da009df08d9fe6ac55fbf2f1.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07a6cb8ed0c07d5ec64e141e78614493',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/c27542630d401cddeac3305bdf01e3d1.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c2c77b3dfc680351e218a719ec92c7d',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/8a2cb166b5a1cf1b7ee581067a15a77e.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a4f8ad5a819a1364c278a5b3796ef59',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/329fa257df7305153d49cbd176376ceb.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3eb1eedc919bd80998404a029ce8355d',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/3a76bfbd5c56f5dd9f8090cf528664a5.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0002cfe2984ba57fe742728ff7f9edc',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/bb280618703e3d02d84cc02185c79e01.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09642e53e85242c29faa0194ef5db383',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/2cddb7863efa3e69c35771401fc082c6.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14168fb89885f1dc5e2063b6fadd9a43',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/4e665e0fca785e6fea5b4007d58d7d99.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b745fa5c42f6ed261f1229a15c74c4d1',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/376048f99ba055b3ef300dcc2f6e4a3e.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6bcdd160577867e2f74fc489456b2cb',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/4eabe4f545bffa2edd22495f2160e61e.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2decf971b457c2998e51cecb9877dc4',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/0daa9e5e1ff593fc5954900200595829.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af71eda52acb657fb5a0d71c7966ea7f',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/09b6d95e57fb0e9bad55c7cec6778167.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '992aae3a35e8d6afd8e96604d19b42c9',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/090bd0fe40965f209dd8fec68eec2035.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '998ea13122bb44da89c6ad7fc945ba92',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/56111262278cf84027b78189df03a874.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1b44bae5b20a3cf76e1b3e56386105a',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/89fcdc946c2e4f5237f7a9aad6f2d215.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a280820fa071512d71c632d7869c191',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/6ed9ac7fe5a6817bf7bb2f5e246d70b0.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '662c3dd11c87efd200257287df69aaf1',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/d166c802f32ee76c9dd1ff462ee8a5d3.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4019e929d9a04ab9501bf1c409a88b55',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/0e07210519d780b7c4afdf9e013e3e0e.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76feada9cf08541115dd2dface1dc0a8',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/26d12919d1887ba846220a7f952fa16a.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c7150e95b38da059a2471aea079f3ac',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/143ab6c27b531183fd2752eb6dd315cc.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '047bad89841129b391f0a5ec51330f01',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/6235c0c7dee33363e6fcf6c0e782eb5d.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca34eefb700e8e6db283f4ca4109f439',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/475d782a1e29d37c2f9bc4c298e245c3.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee315408f13c6fd29196c75b171a27f9',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/bb3160a406d25abe49e87056c0d781e6.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4052240314b21b7bd37da2763fe7f652',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/5b449da0e9b07fa9e71f855db0ccd8d0.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b36595c67a7c7489bdfdaf4991a5c60a',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/6bbec8fb38fe95310f4c91a9327f1469.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '940823de8d883dac731ec3702cb9f2cd',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/8f4bddabad099b8a032f0fa760d315c7.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71983e0b91dfed3c018b02231c0dc945',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/2d53fcd90b3ae6a615aab39eebfc5eb8.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1287679f5430a223547f666f17d143c2',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/48ac6599d69a0b3516354bdde911a467.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '038b6dbc0702f23eee1d4d0335949145',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/3a4b3039bd1152f95498ccab8f600a41.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af083f7eedee198912d0a6cfe88c6eba',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/38e5de44250f3cbeea59ea99f91b7c57.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4c8956a56c3cb32dba2c6aeb88c63c5',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/727c0ddebd611b0aa90d26ee05439a29.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec1eea30edb7cd35d6b80667ce8704f8',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/67182cdf8d358710885617133565e397.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b3d92749ce6614d66cb50b0e9b707ef',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/955ac856748649820b78732b001911a6.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2227459c14a38e69b480c5766e4a388c',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/6c1cc27ea18b0eda383062e9173a1070.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1e7dc1d1f4cd6a4ae5d8466e0b0e626',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/a2258a5d04eb674470399f6711b3fcf4.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb7ac8eef81cbd658f0003284d23a3a5',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/fb1a60d45da25bf5d8369a6012020d58.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2061c2720616483600dd5c722bf75fc',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/91a892eee1362fa49ee6eb70d6f3a370.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16734f89beb24a5aba14e30acf025503',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/41da8954092deb3ac9fa6faf335e1263.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a38b7ab5e5a1654246ef904447cb0acb',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/74ab4a194142855acc3def034833d10f.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be33871fd49e44add554ec8130e3681b',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/06b1169fc6092a7e9a2b91679e5bbded.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf814d7d47e0b6cf2c65eb74832386b5',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/6b039b31d426e3626831eae1737cc1c6.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c520623e836b12555c41e412e28c80c',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/a833cc490021a1dfd76600562eb2f8e7.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e7273c812df92ddc858f5f3d881b539',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/e77699e0dac95d305b77a03373fea792.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ad3a3ded87b5e95338d132c7610c6f7',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/1e6fdee4957682b5e7b25073de8d31a2.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9051731af8ea44941ee4b0bc84f47363',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/5e4220164e2b1ebcdc6ab15b6c1e965b.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b235cac2958c17e94e1b10d60b56270',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/ef19e12c838f959f1cf7868386bb255e.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2728d202e570bd24654ab173506f3de',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/16ef9df3d7bebbfcadb6d4ef4e213386.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a7b25cc6510127925fefe3fae7c2c7d',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/6eb2b97914ad2f92c85e5399e7023f68.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f563b0d505a8873c46c4c6d551dabd0b',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/72c656a2e5497dd47233e6b6b1d01a79.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdf0d1871244eb8202eb9ce67b948f01',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/cbae35028543a3668b5cc9392e650825.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3796a4d53cc6ef114882e4c7d6c2c6b7',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/85a2b089512b49b8ea118e642bea7703.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd05f1860a8237d351d07e515f0c91311',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/46cd0a90044d394d89e23c2f2b05c1e6.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27c6e605f0a7759df7d3906771501c24',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/b61f7bb4ad0204ca0bdc88fb07dc3941.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f32bf84af491567e37c09d2f97031dc',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/31823a575c3b43ff2ff842729684001e.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96892406a173f337665a583146629ccb',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/fa73069defe15dc957b09c68ae7d596a.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13eae2de4f4f36210f0b8d0bd0210191',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/92ebe09e251cf219bc8d49481d6b7a1e.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c0e9237c2cddfc446ba2e5c93066c10',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/e8b5c5015762c44678af3cd84996da4c.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e887cfe489fd8e108a7bf87fa07cb8f',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/4dfe31620a7bd191396faf445ebe4a58.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e591e82a1cfafe0e477c9c9fd872512',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/e3724fb2e22ca69c14e881814bc5cd74.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed31d7a74a304b1debabe447a802f580',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/b5deaed83950aa2f79144b002f14547a.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44f93e84c02595abf7a009eb9db5f2ec',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/81d80ee693a2c1cddb7d11d36ee48dec.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3284bf5a52ed2c823e0df6f925d4ab09',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/ea80ded4207560ab97fc947807a2f2db.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5879549669c0e1fe2f25bfe261e72451',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/3f5ce0a5eefc349b392ed6f3b7bb5600.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b4206ec16fab67fdc8469f45873cdb0',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/25fc04097d1c529391205ab191547163.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8139cc15c8f4e1738e3e10d612defe49',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/ac2244bb9b8af0143f7abcfc1f9a3cb3.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '550e3a0bacf4fd29966f2b82a7523db7',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/2aaeae4fddec39e3c604bbc7f66f257c.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c817242c0f051ba9d9d64e12b2ed3dc',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/e19ddaad6fa598adb8046f20b5ca1949.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58e3a9275e6a1c8e59e15e3f78f2edc7',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/2a3ee26b758476d4cc3123c85d43f0fb.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2a7231a9242e3028ea54d6d5a4b9d55',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/bb82c617355ecc3b2836303f475ec799.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54f898833db218be0780d06295d88e24',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/1ae20b792cbc668c2f2d1adb6c21dafe.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f6d42accfedf9e9ffc2528fe7c7809f',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/98c6247c2b8f97bb06156b117bd5fe03.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e26729aa707c0728ce71a7b9611b106a',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/2a1e3f8f17ccbebb33451b57df8167ef.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f579d04239c2a8a59ae479e1a6520869',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/598c123146ec65ab51a351bc40118f32.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfa3235d4cd769e02be44cd922343bbf',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/c681754081e940c7b97308ec3a2c5d13.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0249f864c15e3c55240a6308d2e74248',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/160cb56ce774c06c70a7dd7be3079271.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ab74403e2aea2de64dcb82afc37d8ea',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/3622e69f4be6c990b740017d96058333.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c8ff7aeee5885aac14f20ae4d369055',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/660f8997adbeef2b0c0855e6eda599ff.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2763605d0219b51b9c2bb27db4fda596',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/87ff27e98f60fab772279efe3396b42d.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0e593d987d1d891bceafac678f1cb92',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/fa062910d8c3ad7c2fc3a533ceb55d41.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c668edd828b12c43b4dbfe6b961ece0',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/d7f30fdeb46172f81e3c4c3e609a597d.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4eb71734808268bf22de8e1dcf970b69',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/7a6b93b7e3d13506b2373c26d58ac7b8.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93ce1bbe81e1dfa991b6f8da92a255a3',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/5da3c8f4321d13ea72ebb4f121642a4f.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0ae3478963ca5d46073d094377151eb',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/cbaa2b52f9e5e7c7eb5644617d828876.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75dfcd2224bbef86ca8395a7a0d09e58',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/21cae82b6073cbb4d3c39efbcd8554c1.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0fea80c98e564168ab2dff5c2041a9c',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/7015ceb51ed40740f130cf2928eb88df.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf4b1102c6dd77a8a2e7f7615e1b3c7e',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/9c957415b6efc2bd9a793287cee39cc3.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88c77f746edcb502f44b9682d64f59a3',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/13622555523ac14080766dbc76cc0578.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f17dfe6bc66e9ef16cb9489c165e659',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/1484a1e260d34db7c9747949d48a77e7.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd36778328928ab37193ec5573d53f37a',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/f93231ea3b80f58f12aa83330eae4064.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e063c69418a5158843230c44e4208c3',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/faac7786c19c4294f06d5a9fe0b56057.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d35a62ea14180dd1caf6b896dfdda54',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/3d95438730f3e066b1cb98b7379847ef.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f7020889fb7f0cbc89a555716d8a4df',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/a3a017b5a7e9c321ff468e9f20d7fb3b.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b6eb171161beac82812bc35afcefc4d',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/1d6f6446270e75e5cc3ea3c6ea2f0b81.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edc6d53ad1e3615689fa9fa2a8f43b73',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/77133e10a54938f3840a0b940c98b287.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '800675c025c55cd666bb37fd2528fd43',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/475ff31cac625b6a33ecdb845c93d759.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b0162a406643d918e0004d62eb02534',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/51ef743193325d7591acb8e5a89b47ca.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f9d8c6296b23d4eebbc06d60382ddc1',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/e45dafd1e24b2dde3af31094dd020fa0.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eac1b9ded48bd132d8e5e71598304f1e',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/678c94be2ee2763360643a3b28e828f0.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15387dc2994751f8186f868bf2da5577',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/c98ee654d0665c9c4af39df67740d6f5.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf4d5e4759b3e954d1b6afeae0756c8a',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/85f32445977168648236661d1d1c1983.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad7e5c5a0e8daf4bd9737b28c1a151b8',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/ab199514c9b10f06dd5b9c4e9c6124f6.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bcee5e92858520aa07df8ba0c724991',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/fcad47908e8924efa7f7686152f2e1e8.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59f5ffae182ee02d3711c8e4fa333cfb',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/956632c4b97aabbb34083c7cca95ff33.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b33a3e3b0e15b29bc052bc6b305b073b',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/ee406b8a4874b8cd21c93ce47ff732b2.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5662d9a937be52c0ade8741e4d093450',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/ec02261644f983396075f965d52c4fb2.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52bbee8c6fd55f9e40366e081ffc153e',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/e6c00ea23edeb5c7e34fd2ea4f623fb7.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '952dd774cd97c4999e4c23fec16f66f0',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/dbfe0aa47378d38bd6d31a775681a3b6.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8be35a1c4cd4386be697906cc45edc40',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/7237424431b5b22ae9b35301838567b0.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aad8d7c205523756e50e42d9e78465dc',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/dd4aca1687eab93634854c44cab99b12.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bb3d4570275f58e8527c5e7604e68bb',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/e39b806be53e313aaa3039c3a8e476f2.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e916d4119fd1f0b522cc6ace11a0693d',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/8a0fcb474ccfd61343b05a5bf20e81fd.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82f7d4242d1f752d1db3a60858daa759',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/644814b8927f53c477892378f5e2c525.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3505f76160474a2a7f25e12d09b8023b',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/c97d32101ecb2900a15c2fd0fb73cd5e.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60a2163374a9b181c25a70338f2a254e',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/7e313e5a1b3c388b7464532fbab0fef9.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3943297559b1ee05c603f16aad3ab688',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/dfe4f856cba159b35ac4705ed5dc97cb.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88ddf996b89de8ca8d1fd0e519a9a812',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/37c0b36f1bd6ffb253f07a0c20526284.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b673dbf65bf5ae7c685fc4a049513f67',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/dbfd30c1ea027f8f07d6992b03abb2b8.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4da235a459aa71647ae83c466aab3928',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/c1e94d5dc02b6600884785891c1b4a99.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8bdce835e34aba0a181602805e249b9',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/746f766db11c0fa57352900b458559a0.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afff5579601f67263d8012e9dc3573e1',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/e8cec3debba7e8298396563a199b323b.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c9d220c6e4393e0a5a5c40ebfc6eb6d',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/fe62502915a07521c5016a05422573ab.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2874f6b56c34d2c180ba4becf205be2',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/eb4a09bc1ad53e427a07160f4b6b6919.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd06249b24acc12d75e6fb4791d33a3fc',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/3be0d84b5b9156de98d7cadbaa3b3f6d.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e1767e1a4e29d5b5e31929d98cf3223',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/8cfa4e25995784c6aa08f645794f5afa.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6a7ca819e9f9b394cc260bd8aeb04cf',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/8a5e482811dc80b124cbee3d12d0faaa.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '913413c5753c9ef7a3743ebb3a5e0d68',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/daf3b880f9dca56376aaf698af9b2dae.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42e5402c113f21f39e7c53a1df0c72f0',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/8b7a2f5fd78d28b93525500060090f79.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b17ccaf7b83b8d7c2b7261f6dab31c0',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/207764493740719c930c1232e4659459.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90058d58dd1d1cf1e392dda2606613d4',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/0f42d285969c85ef1e9cdd2a53d8e9f1.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30146c36db4aa85baf4837caf33b6714',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/858ecea8bfac6d58611963363246476d.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32d050b9a52e9ee2872a17f16569f3d2',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/cd74fcdff8514efe25e4dded8db0f545.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd959a35c6ad41659cc87c0810392b87',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/f0ca2e4420c4696492ab5fb885f9c6a4.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93a8ec128753056303a0cc46718cb1f6',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/7cad43ec0c7adae29b84339ab48deee4.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '636f1bb4e3443c458695e1fba08399e8',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/c2b31beb767c21660620e00b604b3f3c.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d65af3c7ada74ce421245eccc38a6e5',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/01a5d885ec9238db6de7783ce8c8a2b2.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9009c55a5020d346918229d97a8663d6',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/8b11ad9ecb7076d52fe3c28d729d3c6d.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5258dbc3d130748864f1f4544547edd',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/d0f91e929f97621017316d5c7264e88c.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5dda524c5501b32cffe84afeb333981',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/5fa88162548e0170c25406a330db0961.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e96914281c9f4e2026605aec614df9a5',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/fa2196ecb06e01b7fbf2e7accb15b111.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67e5c9c8effea0a4e7dd1b48f62e8368',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/6e56aaf32daef50ba40b7cd1f9692cfa.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33c608f73a24e7a76f457ca1eef04647',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/046b895bbd486e9539e98c2da1c474fe.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c097e2db791c3d9774debc882c8871c',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/ae3ad36c709bab1c1de58e4be43f760d.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e498b7556cdf3bb94ff86c364c22e263',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/5a205c3ab8bd2dffa2c010ec8463e45a.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de8ecc0651b8c0c0588250c5374cdcd5',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/c2780725224f3842b7f968d68784bd69.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '944640789aeef540476b70bf37b11de4',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/13feaf22ade6efce34abc77419e04868.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4756233c1ee7f89644ea380c492ada4',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/93074bb972d90e41eae4dc9854804608.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '160a98b4fb4d05d11ed2188feedbb425',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/115253d81ae6738ebc18f73d2c5ed805.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd23b4bf213fb2163194db1ec0aabde6c',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/7b68ee5dffa90a852ceec1a62e4ce3f2.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc077d4b4ac5bf1a260b5fe965f74574',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/f12ee3d5c101de1e613fe8764911c9a5.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6e174cc50d363c47dbfee7987875519',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/57b5098e045ebf60675101ffd9e9a611.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c557f0ddbe6771d9fca1957d288b4850',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/6f01bb9ace75ff43408453ca452a1ed1.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '093d7d8472162b8b73d8820e77973d12',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/6a4718166a00c33ab6feda9ad76449e7.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f5a05853fe9baacf11b0644ca990ef6',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/4ec6e8708b816be78a373cc99f025372.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6a61a76ee50da669c882b5490715f83',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/a618ec540c55b7f5b364be4c95ee21cd.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81d5e98d7b1622bc8c5a3d0f9cbdfef4',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/ef22846e16ba6081fcda92e9c6389219.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d3dd61edea25b5bcf545fdd32c22ce2',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/e29c2483d520bec2cb71dd495d58a93f.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2465ff254584060ba38a5dd5d128b201',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/c6883c9163b4f020e8a2c8dc7e701176.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72a0ad45b49e72889d0f3e8042ae2921',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/cea15b181b183980a55ea4e28cd4dedd.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb3b23be4cecdcaa1df785ef15edea89',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/b35239b17fda5efeb3305cf56890756d.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c10262a504e61b8b9524afb6904503ac',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/10294a8fe294a740efc7faa27aad130c.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1ea18be0c5cee6119cd65e795084ce3',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/c51660afd9636797f1311804a5518d18.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac070184968a52de4d5897d2ff7729fd',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/06da1a7f17fc5a3f91a7d86eba75de24.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30e555fd0d158cdcd4374ea21e8da016',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/ce13e3e2987962703ef3faf1113d8083.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1213f3a81aaa0e46a411d68970ad349b',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/e90c847b18042516a752921ed09222b2.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc08c22d20f2c2a828811ee4de7058cf',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/9367a681f614569a6ffcd482d1f246fa.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77593c8c7706579d2ac88d0745381b01',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/bcffd892cab78d69396f7c14f02d6eae.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4e8a54eb7c116282a12c6ea09b6c8b2',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/6dd7056563d57c0e63295f187a8d3f64.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be4bb2031dc0a243fb4ee7f83d2c2888',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/2fb44278f97cb5241365809e1bc41f1d.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aec62cf97a2e634b8ede13664f24d7c',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/ab6062ffddff7e4fadf2a0375a9cb1b1.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4c7990806c1df144ee869033315f3dc',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/1cca3e6ff54de590f9c717a497fa8fd5.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aecb63d63ba3eabb088a04db35db4491',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/a921755eb770c03e45f3d977e17e76d7.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77e0a36c30c992e709f85b79133c1176',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/050fe09534885abe0bd2346f66e2af35.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cdfb3d73302b18c5bac98504e7982e7',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/d6e54a208861fb43a00caea056569b81.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef8ce6047e5e77e0b1600676c3bba928',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/97fa5d3d77af3b86f18952ff615a392f.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a723bc2a1b9aace1ab6b4972ea0493c',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/a3298da3492cf8889aec6b06f626eb7f.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3602bc42339fad05e5782cc87ab61b74',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/0155abfedf24bce53e790be24301a7e9.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7673d8e896b0bcc2b81424ad63e2e3fd',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/73f7e7e4152a851769b461c03da743df.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e3001e7f7005539100e0f6dd8e3c248',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/9924c43ae1b68fa4746e012e55063ed2.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '386ec49b36226741a33c9a51a5a88db5',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/e9ea03879355f6a634d19ab01cee933b.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8616297a55e89aa9c9d470bf67eb8689',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/2e5616349efd954a6c1b967776597e41.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a3d89648a2568749293c5ba330c3617',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/305ce28dba33260bedebc93193c27d10.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae4dab6fa959fa607710b102e336448b',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/b1517a0237be490c37044f692d70e7cd.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0eb96a1fbb4a348f013832777d42c2dc',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/89cafaf2f663612dbe747a2de7a1bc6c.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22407c91bfee62927a4d28bcf15f8c38',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/c12d9c6d2ef899742ad5d9d893f667e5.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5da4d755aea28c83fb49598f5f027214',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/a1d4773348b6a4472556d7d8ab9583f1.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92976d685bce87ed376eab01963634ed',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/2353e20fa4db36c8de2e2953e47d807c.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cbbda1b3ba06fb751f73fc9cc9f7c6f',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/2ff108c85c7633d81a5963e6f3adcdd4.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e765749a37ad0dc708f7e08a11b921df',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/3718754a89ec6851952603bbfbacb264.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be0ef6b479b3af34969491fba502a3e2',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/896808c04bf7da65440c9872a617f238.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62a5a3e521194b97d8b6afc86cedfee4',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/adbda9372d467427230766cb34d384d5.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c22c72441adc95b99cf4a0c11251ab4',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/b20837d0eab4d535438cb2883fc31e34.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5e6ace4f3b7d5a514547c9fb6d535a8',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/3c452fc296195c760dc7a3caca1f350f.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '209f5b83d225a0281d95cd97643964c2',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/d3eccd96df99e2838bc1143cccccb22e.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bfb035a561fcb1ae2ae0d4c1913bf97',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/20670ad5fdb77c741388d6013120a04c.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee0fbda97f30ba49518eae514525cd1b',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/b1beff7566d39a730a66953f3367078b.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2fe764b2cfc5e6a5f9a907d12277521',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/d949e1ec6f2294f96ca4ba75d05cbccb.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36c698ad362d8ee0bdf4e63e562af693',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/dd10ef29016efa090515482a088ee00c.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bc445bc785059b8e3ecf2c582b73d68',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/156df0981abe247ba617ca678b7fb373.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24cb4d59ac6bd656c1a9dec6dfdbb191',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/f70fd2bbf97e19a38f73224e2f71d9dc.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c485163018419da269356c35e4be9a9',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/25034e098b6cb5933e0d419fcd4f4589.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a9fe6ecccb5b935958b4cd7ef84f813',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/25889446be1103447d70291745df25d7.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d7aac098c72b439d205896ed91f55c8',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/c36aaf2918cd0a0acf5033c13ed841aa.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9658845c7a330638de73b4e8ec410e9f',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/eb05d98bfeb3268c70f1fa4ef85d202d.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b541d97815b9d334baa867ea8c152767',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/88018f8a2cf48db3893641d11550a92e.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '086722c5377dd28f48c792e275d7853a',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/57b3b44fd298227594a760a46d25f7d7.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b19ff77cddde390e4e239c4be26f25e',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/88b6717f0b7b72683678acad67b56761.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccd82c0b6e00abdc22ad9f243c45c751',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/bbed94e6a988d558b0b66477492ac16f.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73c5d172afed20861ffea3169854cb21',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/c8b114ba2f1471bdc2df0ded900c5d68.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41a9625a42fb425a00b00b02031f30e8',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/8f218ce2098572241d2df9b72f6bc68a.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa85c86fbd60ac8e17fc942394e2ffd1',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/4529ded1cc1e8187a4658a146ab661a4.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46806c9dd7a4140293214747e1703f51',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/b4f467375d569c3813543daa422c8f12.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '307fb0c3d09f2d1541d3db56a0d9de90',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/7579c816f0ba9fb52c0978c8d68be2ab.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d6ac0a7822f6e28a6b9ee9da8b6da8d',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/74ff8853acb95bb5cc095c9c8b2c648e.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f93fbffadf051e1455bf0e9ccb5e3f86',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/4741e57dd5a16606625dd72b650f423f.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2a86731061dd34c079f1ca90ae800b1',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/9bd049068b0efdaa357e6451bb829fad.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ff7469b66338bcb14c76b083d5eac5e',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/6258cacb20b12d06974822e9f512f140.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23349d97cfe77e9736eeb4e227d02a22',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/9aab6273c096c26b61693b05b797cf0f.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8177c4967dde658c7e32f1d372b32eda',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/9fd0c992f05a31a95afd10c72df1067b.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c464cf71489481c7cb32286ac920007',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/929b248ae5a4c50e9f9565504a837c42.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb3162a81bfb911388019841a6d81985',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/1ccd1c5c795453446217df89cc1dd039.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10dc5e9b75fa980f1f362b616005e8a1',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/9a83cf6bc7747152faad8df47095d81f.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53addc7b5587f51b71a5ad6ea7b689ae',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/c0ec289038d8c92c01514c8dc585837a.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '286165959f6f747ad8beb3bcd667ef72',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/a0f9ffa425a6191b6c0696d77edee0a0.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '604f41b4809fd8dba5684beb680db284',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/e7c67f795d87f4812538b786084d2e5b.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c5d36c3743ea52d084234583da13610',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/7fea574e1539bcb417d64ee25d2c8be0.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ced7c88de5905e6228cb05c2377ce532',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/1daeb3f7a68c293ac57e2ce4f3f7d6fc.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f5a09aba48091595130999c2706bbb0',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/d67460a207715c568b31fc683a1b427d.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b86ab3a6c1d915a0b12ea25d6db77b7',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/db517132f68f6e8c1db633c710c32bdc.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0b725ef49d8f368e4bbe6b931b7bdf8',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/428f5ca5fa98b2a579a7a4e7d69227d0.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a594cea79ff4c8ddd7f303677ee4ee92',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/35493b4c15f3b43ffcf40eb3abf28739.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b222a0d2451f529b1e68f1da3d78b656',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/76aeaabbf89cde5710064adc4e7be13f.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d49b17ed8b167b86d82d6ddae3badcb',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/86c6f3a705e7a22079495f590d6f4d85.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '346660ee28aec422a06298e6ad983b2a',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/f6d5cccbfa6d61bea6ef8e036268e698.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa9d2f9e2d59f6376c3ff8d464f74242',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/7d0e6f77c36193c529885a370887bf4c.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '613e92f31082e0ad57e3bdfb3e3b8f07',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/70c783d497eeadb5202f86c5cefb0094.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cea75e01eaa8469abd93aa29f5fcee1e',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/3f9444d3099716339d21f19377d0b283.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2e9b059cc40e2ec82879a7774293fc1',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/5b694c1a750b14b05b1b189246bffb0f.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '702ec29ea6cbb53345340aa58480132e',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/7bda76ab7c5e36830dfd0d08048d5afe.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7598861dac97ebe4eef710a98749298d',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/5876bd0bc49b3d81a801e3966d40fab0.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73cde9b5ae0086f1e543de48f8719c9f',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/af19f4729ac5ddeae3c31434584bd489.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b52a4dce9730a3d931c14ae07303d32',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/9989b49fe310f50aaccb28e8c051aa98.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '852530a5ca07859710554175c87e3227',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/aa552011b50d7c2695970da03454e646.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72967a14938042034f5a97e5ee2ae609',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/89a062cb7a1e1e948115ba8cdf726727.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f107eb796d2983a67472946ef19f6f97',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/db46cd823577ca4c8309fc96a09df142.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '406aa4f5a64cb377d4218316f5d1a172',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/42568393897511f4f770111c367c675e.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c51527dee0d97f60db5e5499dfb758eb',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/4e2383a72def8d1d02f0d4baff111419.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6063bc8f8cd8f1d8b33a508d44a1705f',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/ff291fbfe4600434a2e5655c91c9427f.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c95485b0f87a2849620f1a64ce98cde9',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/1b14bf7c285f51ef3b9eee5912e6d07d.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e474ae54d18464d84f4e84667199fcf8',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/8b04ad024410cea9e4cba5193bc59d35.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2566736dc6493bf677793aea00289fb0',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/4e01cf4d25f04acda8796f71b201f47c.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c0adbf5b190966fe0a5abc9ab337ace',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/3fdf4bb9899a8b2a751158f9befb169f.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2adf63c03e8332573febeb8ef7ba16cd',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/692c0d0c2c2622ad936e2f05c8acd39f.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcd127d5edf8261ab49ef63191ec836b',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/268f60e8bbea93b376b8cc3e1ffba0c5.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4df08a6fd3f93436c11cadf4e0fb8f27',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/a6e0dfd06951bb907f3df56f6e923c5d.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ffcd701179fda129dd957aa4b5841be',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/cb77113e57fa0b568dd5cf0042f19784.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4be2b06a8c37688b65ad1c4199bf454b',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/1e5002b719a1d031695f7a652647f4d7.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa25ecd34bd81dc7692b89630f93d1be',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/d5124a1cc01f8756af52230e5c76e7e7.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36d667dca1539159a8b88bec5c239b9a',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/1e5530069da28c4514cc9e86696f2804.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36a0863b0edbd6963bde988b5fd9a583',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/f0b07b005ac3199ba74663b42fb7bdee.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c18ca09498acf2435b683cbf8ee68ec',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/544daabc517b57bd1a297f13d158020a.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7800340aed1d92ce527c89c11f29713',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/d2079397db10129b1cbcbd63e7629a2d.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd067b2907fc3534324d604b3bc695dff',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/90b49f12213bb9b93d87b823f9e46760.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '217429cf7d424fc333e5b52ccfe292ef',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/e5b5dc627883acb6fb5317405f59b875.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8959075c0fbd54937f20caab67b8563a',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/9bdb73aee4e59a066b0c7e48c4af0d72.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '449ff77f02b8b4715289cd60f1a347e2',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/02ae7bc98a68a8b128ec835e16802634.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfdbf213fb84259be847e2b204fe76e6',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/f1582ad29753309895ee1d6806a750f9.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28592b4db7193e05743bbf2c2268cb04',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/b8b3dc8d0781ee337aa105ca8af397e5.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc515afef8fb938b8965361ddd536644',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/3a88f49ecdda2a09d9e6ad1cff17fe76.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2c334b2746934a6b4297da747ea6b7e',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/184237854b4692797c1843dae20ad496.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11411d7d984eee0f6a679b207032efde',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/baf5ac2a779ed30d9b9855add6b4386c.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f38a975bd4fb4da16d6eb6bc0f733dc',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/7df3c092cbe2a2ae143bdbb187d21058.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ba1e8a2eb31e570504f1f1edcc2d59b',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/c24baa21dc40e4ae774a4a7f7c4bc8c2.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23d92b0f0c84d0f80d0465cfb3aba443',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/4792d1caef43e0d1f816d06dfdbae133.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5441fb6b9f83c8d610c0c4763b2a638b',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/f40f118c01259c3ca6cafecedddf252e.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f54eaa87542b7cc4907f62a79f68ef5a',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/1322e8702f4bbc76399f4512a77053f0.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74826eef16dd608fbc5d5536dd5a4e5d',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/1a9a5eda623a42bf6505938dd393f5bc.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '306f084890821ee207ebd5f5ffa52250',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/81dca121a252a9d1a65df113aead3c6a.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f49fb3765b8139557d32d017a7a23c9',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/4b95fd39e995d55f5a1846b325475ded.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cafda660ded662543afe5242017f523',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/57d7d8d76d28781eec7c03e75d2e7438.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edea59febdd59f83750c8b8817d3c683',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/6021858f46a2297201e85314e47cfcae.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a558117cdd27eb21d39ddc2edf41c19d',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/6ac6e95d1f97044254dc87bdfb99e2de.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2c7af1d107479bbf79438cac3fbfe7a',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/40c2af137821756fe4da975eefeb4f5c.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd76a9d7206cedeea926678384f95b5d',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/c19dae44b265aad60d3789279c2b0742.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb07181387abf29e14b95b02b5a0b3d4',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/3a19307fd399a79cd81ad5cab5b53e36.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8052fb4cc39af4422e32bef7ebae4e60',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/fc0098474be07290057642370b56e4fa.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17931787ae7c5de4c2a30572739899d2',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/a42d296fb56693b7f2b264634ac22dbd.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9248ecbb8fb87714b93a6ab137c2884',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/5ef604b78ecc1423a6f1c53669deb0c3.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '955e00cabe577ef94b092a43bc5fc0c4',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/28e246a5a16e0a843ccb58dab9db3f0f.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2887ba99ca2263cac19ebb79de1ad161',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/3cb7ee82957da8b2ed2d0b374616fa92.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1a68954cfc6cfc62127800f9fbf47fc',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/2b514ae76578e080f0e9fab788c77405.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a45d3bd77f69afeb503de6cbbfce98f',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/a4fed9e25077c329f57e9e157097eb6d.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d4d0b1b9681067b3b9e2009717a4040',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/590d13af9e8b6726130d0ea47f9421ba.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '493e2840eb13ddbb2d5ce0d1c849b667',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/7a4685953d8e0010f48fadb8248dc6fd.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0b1d30f9a6b5a6b449b4931afbf4ba2',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/87c625406f57c52d7ca4dab3911e7b07.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '503085158641d98898a5da90980b3eb4',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/7eb8a7fd20f7b81c03a951e73b6fcf12.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23878a5c7163e3fb5fb93a255eca367c',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/d2ca8d7da35f5993ebd6406591a13ef9.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93d5c7d3d2e797417a28e2258795863f',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/e19928ce1f3aa16d66ca09901756d2e6.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ac1054f2cb24608169b796265f71454',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/99882741fb9ceae18388a2e16ce807c6.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57ca6e946ce809ac9f70fd24b2c83225',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/99498d504c564b899f0e28655a24da4c.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8b666dad2f5241891050be3e2a00473',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/e218f8d54970b22e0ca5ba47a1f7b870.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71835b65fb4e050889450468bc025209',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/6f2e9bcbc0bdd776d72455999321ae64.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86b5b292ea98c637c839c171861e1413',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/72f3d6d1b841724d2d62521643f1c506.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58c938b3fd4f581f73d8bc1b2ef1e517',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/96069e634a6e4ce2cd3956eb5248438c.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b2904151afa4d6ccd8635b8da6227ba',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/f1a063e4e13bbbc4c98ed96955ef2abb.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eecdb12235dac9f32583e76b2be17157',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/855bab0c3b9eabd5c76b8b7d290081de.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '002168312a8ef5a3974a1f8f95b94d11',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/afc95ad61f803984d13de2e7b235a079.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd7fdbdfd423f2316e9ce37ee6f9e835',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/63872273f66b1ecb359a6e0145c92a75.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '611b936defd6176091294524ea8a891c',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/6328f0f84fbefb510420d4dffb3348c2.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdf7b0a02a190fd6ce8a17354e39709a',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/34bb548b9bd7dfee70ee23965f84949f.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e86819d577c46a9b56fe20a68af328f',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/1959587d5a2a03b876e85e9b931d126e.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '421d8f5f9bd561853e042698269ef154',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/4a7719a3c9af0f69e57004eb3f3e104c.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34e3f6cb2b769250f4c02874bb21819e',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/b26a733f02f137ba01be5f067a99bc35.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1dff53bf6ddf28d1afaabe6349e8855f',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/d10d62e7acf4ee730b7b901a07e31791.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d8e35dec02512609a71f3268ff74b1f',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/555b14d7b8ddcbc94ff445481d757d16.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b738b6f0a914ab38f3d3934d420c09e4',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/349163368b1fadbb3aa99cd3cd2042e6.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c494eb5c2a9ae2e77a405a055520e622',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/9553f312f1c8c828d5b90f13e8ebc396.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3db8f8c41820c4df292006d94e326658',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/6a884a6c643d6659c60a27f070857aaa.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe2cd2b5da3f2a36ea1ce2eea7df36cd',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/5bbfd2d51d38157de4f3adb489c97b3e.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db5fd0b65ab139ce3d13b7442dc63a8b',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/0766a9fc5f5a12e03b35b9c8ff127fee.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b923e3f84b2e5f2635254c85f2d3c284',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/d5e0ec86c6737ffb53444db5d96df243.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a4b06819f0121a114180e780f7836a7',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/72d787ba573bdafe2c3a45484a8139e2.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26f080189f8399560947732f7e4c875a',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/ac75e1c592ba41a774c1c33ddd32c6b3.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '166f189603dcfec331bee363c594223e',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/0bc0d94bf91c796d26fbc36897a1095c.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e39527893bdaf6adfa13d9838a79b26',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/c1cf95e3ed68db6600aed43551886d6c.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2e76b73f47c83dc1269d2a349316605',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/d89bafe3e8b19d0bff9d990ad88398e5.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a653acbc83ec2f266a95ef4c3dd00493',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/5cf2251e6bfebb1385b74587af59eeac.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5af7491ec61dabedb643471ee08da5a6',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/ca99ac92b31995d8d5b7cb39bd14ecf0.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f89e063527810934f0b3668ef802854c',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/b8aed2be5596c55b44bb3a18fb8ba8db.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '96d4ee518b1513d32a04903b056a5974',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/8fd7f14cce3c239f02e79b5f6e671aa6.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'c0b8140d4458fb3ecf34429dc1c104c5',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/5b5349c4a65406f68478a5723524531c.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '01ffe4837b23f6bb321464df5ae4a7d5',
      'native_key' => 1,
      'filename' => 'modUserGroup/ca114c090d2ef8ea3cb4cdcb6c4d5f12.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'f25384db1fa3f4c09c21386a08e020a5',
      'native_key' => 1,
      'filename' => 'modDashboard/c5f7bee0a6c779338cf1b51b48a898a9.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'f0bd79c0b0649736403b9659893862b1',
      'native_key' => 1,
      'filename' => 'modMediaSource/77c101dfbe7f041d0dea8eaab3081cdd.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7a4cc769d82b2670d08867a5ce456b76',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/64d2d6bb66a03a3dd84ca0b51f8a552c.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a10684fabe032c2cd5911dab33a9fa25',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/48f2f7a82d8a10f30c81ac3ff1874184.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f68d62008fc801f2756f0d13cc11b5f4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/0dba2a3208f09d0dddbe0a19d3e9fe47.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e8eb20f644cf7619a1d5cc398cc821c7',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/26db4e46b5a82518d0b2530d1d953442.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '00ec53309f5f81eebf314dcf803d9ce0',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/00d53b488a767822535032b08b5fd30f.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '113bc78c476a2187652930b435bca75b',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/168fc36deee3d369c46e5913c8707035.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'f4ebad2f2396286f7df1eac1be50f339',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/367ae76781a7d01a0b42a89464cf5282.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ee792e6c08edada20f235b7c777c6de2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e9e9b4ca8faa20c2c1d5d7f8eb7d4d6f.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '46dd8b81f50e58f4da1539874b1ceeb9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b35f60be0daf71cdf3182bba7ef832c0.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3441f60e086e9f998f5381c8d908a210',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/95e9d53c081361902a0dcfad6690a035.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '1dd89544f1b5c1e20f249c5c3a91b4df',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d2d0f624e7bb876e81d2f7f2701ca9d3.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '6f622a6d45811e458a4600edca82fecf',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/22a1fcee7ca99126ee1a31dc408e6e04.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '8f4a15319d15c1d4bb225d4f3b48a5eb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ebcf3a8df8437a8b68e6bf9575527014.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ceeb761b4ffbe946af253d8e5a24200b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/be82d518269a9cf913db980aecd8d014.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ae716da2849b24958592528142ffd3be',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d47cab8231b7c8c10910b2587b13d898.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '78d65ec60316c9063642b6b6461d7d63',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/78ac9e8610aab3d19f317070d7e9cc51.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e0f0bb9a96738e6b8d953c604964fdf7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/653ef02864e1056d38ad8518039a7f01.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e47a667764ab94607fb235f5f7eb01ba',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f9315b9576f8fcdc1c3521795a2a7034.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '050717572d0fb2d3225f6291428eea29',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/dc9abdaecf64ee4115370a1e048352b9.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9574fe67aae94532fdb0a18b56d98b6d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e47c54ae62d706a672f65aa0a24c9355.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a7318d9cb1ff1d271d493588ac0c75be',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/6893c00960ff0e80bac23cc8bfc4caf4.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '130958bc68cec1d877677bef5d032320',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/73e17c5d2c96d73bed6d2eb2b7cee6e2.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f6041b73450c404e8e8df92dea44a18d',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/4940097ce528a19bd98a91d3bc9da0bc.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9a864e04ccedff9d8d906045b9434262',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/66ea8ad5cb04aaf2b9e7e758607ab4eb.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '057b579b47a67980dd8bf0786140ec65',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/fb7050c8bfc69118cd24a7c3cb0c83cf.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '651ad874bc3a4b972ddaaecab49bb2be',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/9338126ce4a8d4ef959cc7e8b72821e2.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd28e2e736a4ea41fc0fd8e95ffd6b5e5',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/bd1bdcf94f48fc70fd05286eaa5edab3.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '31f7fb8b7b1cd1441075414eb72a6b49',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/ac9cf8b80b8d4ab62644cfdf9ff24b7d.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ba4c99d474d7463e0e028ae30dec1b87',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/5509af4385b0b06bbf04ec447dc8eb33.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1fe1624ef5fe377910bca0918e8f52c4',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/ce9aa1402eca21732230f74e6bfe6112.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c5404d9f631ccd280935844ad2769ace',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/289e650a844f1e61825832149adde319.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c01197b6a022caa8e969afd5beb3226a',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/9e7152434f23e57569e4f2bea4405606.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'b81b94ea5bb63c85db303a6744d517b9',
      'native_key' => 'web',
      'filename' => 'modContext/0f1d07e326a66e5d5dc0fd03577a74bf.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '3af51f460474b4dc71992ab69c4afb85',
      'native_key' => 'mgr',
      'filename' => 'modContext/334fb36c4a91cc03578b6a02b912e717.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '03ddf51d3a578c0ac2cc1c2b3473ce7a',
      'native_key' => '03ddf51d3a578c0ac2cc1c2b3473ce7a',
      'filename' => 'xPDOFileVehicle/43791ccb20dfeb232b1676f6a4ed2a79.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '95a5273a88da5339418b913ffe217f28',
      'native_key' => '95a5273a88da5339418b913ffe217f28',
      'filename' => 'xPDOFileVehicle/366c44609ce38a5d983f19c61789a9aa.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1052fb9bdb878118909790bfd317a0cb',
      'native_key' => '1052fb9bdb878118909790bfd317a0cb',
      'filename' => 'xPDOFileVehicle/e3dd8c18189007fd441e2fe3a17b8aea.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1d461b72cd65cc51aed92275bd21551d',
      'native_key' => '1d461b72cd65cc51aed92275bd21551d',
      'filename' => 'xPDOFileVehicle/670c1945258cbc8f99968b4db51b3a1a.vehicle',
    ),
  ),
);